# Lightbox2

> **[Lightbox3](https://lokeshdhakar.com/projects/lightbox3/)** is here — Zero dependencies. Fluid animations. Built for touch. [Check it out →](https://lokeshdhakar.com/projects/lightbox3/)

Lightbox2 is in maintenance mode.

Lightbox is small javascript library used to overlay images on top of the current page. It's a snap to setup and works on all modern browsers.

- **Demos and usage instructions.** Visit the [Lightbox homepage](http://lokeshdhakar.com/projects/lightbox2/) to see examples, info on getting started, script options, how to get help, and more.
- **Releases and Changelog**. Viewable on the [Github Releases page](https://github.com/lokesh/lightbox2/releases)
- **Roadmap.** View the [Roadmap](https://github.com/lokesh/lightbox2/blob/master/ROADMAP.md) for a peek at what is being planned for future releases.
- **License.** Lightbox is licensed under the MIT License. [Learn more about the license.](http://lokeshdhakar.com/projects/lightbox2/#license)

by [Lokesh Dhakar](http://www.lokeshdhakar.com)

---

## Info for Maintainers

- **Issues and PRs requiring review.** See items tagged with [\[status\] needs review](https://github.com/lokesh/lightbox2/labels/%5Bstatus%5D%20needs%20review)
- **Questions on Stackoverflow.** See Questions tagged with [lightbox2](https://stackoverflow.com/questions/tagged/lightbox2).
- **Release instructions.** See [DEPLOY.md](https://github.com/lokesh/lightbox2/blob/master/DEPLOY.md).


### Local development

- Install dependencies: `npm install`
- Run linting: `npm test`
- Build: `npm run build`
- Start a local server (e.g. `npx serve .`) and navigate to `/examples/index.html`

